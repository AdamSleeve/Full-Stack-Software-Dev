import React from 'react';
import TodoList from './Components/TodoList';

function App() {
  return (
   <>
   <TodoList/>
   </>
  );
}

export default App;
