import React from 'react'
import FetchData from './Components/FetchData'

function App() {
  return (
 <>
 <FetchData/>
 </>
  )
}

export default App
